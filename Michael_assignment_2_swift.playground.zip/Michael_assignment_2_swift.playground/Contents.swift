struct Location {
    let x: Int
    let y: Int
}


struct Customer {
    let name: String
    let email: String
    let phoneNumber: String
    let acceptedNewsletter: Bool
    let location: Location
}



let storeLocation1 = Location(x: 3, y: 3)
let storeLocation2 = Location(x: 8, y: 8)


let customers = [
    Customer(name: "Jane Doe", email: "jdoe@gmail.com", phoneNumber: "1234567890", acceptedNewsletter: true, location: Location(x: 5, y: 5)),
    Customer(name: "John Smith", email: "jsmith@gmail.com", phoneNumber: "9876543210", acceptedNewsletter: false, location: Location(x: 7, y: 7)),
    Customer(name: "Alice Johnson", email: "ajohnson@gmail.com", phoneNumber: "5555555555", acceptedNewsletter: true, location: Location(x: 4, y: 4)),
    Customer(name: "Bob Brown", email: "bbrown@gmail.com", phoneNumber: "3333333333", acceptedNewsletter: false, location: Location(x: 6, y: 6)),
    Customer(name: "Emily White", email: "ewhite@gmail.com", phoneNumber: "7777777777", acceptedNewsletter: true, location: Location(x: 9, y: 9)),
    Customer(name: "Michael Davis", email: "mdavis@gmail.com", phoneNumber: "2222222222", acceptedNewsletter: false, location: Location(x: 2, y: 2)),
    Customer(name: "Sophia Lee", email: "slee@gmail.com", phoneNumber: "8888888888", acceptedNewsletter: true, location: Location(x: 1, y: 1)),
    Customer(name: "William Martinez", email: "wmartinez@gmail.com", phoneNumber: "4444444444", acceptedNewsletter: false, location: Location(x: 10, y: 10)),
    Customer(name: "Olivia Wilson", email: "owilson@gmail.com", phoneNumber: "6666666666", acceptedNewsletter: true, location: Location(x: 8, y: 2)),
    Customer(name: "James Taylor", email: "jtaylor@gmail.com", phoneNumber: "9999999999", acceptedNewsletter: false, location: Location(x: 3, y: 7))
]


func printCustomersInRange(storeLocation: Location, customers: [Customer]) {
    let storeRange = 2.5
    for customer in customers {
        let distanceX = Double(storeLocation.x - customer.location.x)
        let distanceY = Double(storeLocation.y - customer.location.y)
        let distance = (distanceX * distanceX + distanceY * distanceY).squareRoot()
        if distance < storeRange {
            print("Name: \(customer.name) Email: \(customer.email)")
        }
    }
}




printCustomersInRange(storeLocation: storeLocation1, customers: customers)

